
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php
echo "<h2>Task:01</h2>";
   echo "<br>";
for($a=1; $a<=50; $a++){
	if($a%3==0){
   echo $a." Star";
   echo "<br>";
	}
       if($a%5==0){
       	echo $a." Struck";
       	   echo "<br>";
       }
       if($a%3==0 && $a%5==0){
       	echo $a." StartStruck";
       	   echo "<br>";
      }      
}
echo "<h2>Task:02</h2>";
   echo "<br>";
function CheckNum($num1,$num2){
	$roll_number=44;
	$sum=$num1+$num2;
	if ($sum==$roll_number):
	echo "<h4>It's your lucky day</h4>";
	echo "<br>";
    elseif($sum!=$roll_number):
	 echo "Try Again";
	 echo "<br>";
	endif;
}
	CheckNum(33,11);
	CheckNum(24,20);
	CheckNum(3,11);
	CheckNum(33,1);
	CheckNum(33,0);
	CheckNum(33,11);
	CheckNum(30,14);
	CheckNum(33,0);
	CheckNum(33,0);
	echo "<h2>Task:03</h2>";
   echo "<br>";
even:
  echo "<h3>Even Numbers</h3>";
  echo "<br>";
  for($i=0;$i<=10;$i++){
  if($i%2==0){
  	echo $i;
 echo "<br>";
  }
}
  goto odd;
odd:
echo "<h3>Odd Numbers:</h3>";
echo "<br>";
for($i=0;$i<=10;$i++){
  if($i%2!=0){
  	echo $i;
 echo "<br>";
  }
}
echo "<h2>Task:04</h2>";
   echo "<br>";
	$arr = array( "Italy"=>"Rome", "Luxembourg"=>"Luxembourg", "Belgium"=> "Brussels", "Denmark"=>"Copenhagen", "Finland"=>"Helsinki", "France" => "Paris", "Slovakia"=>"Bratislava", "Slovenia"=>"Ljubljana", "Germany" => "Berlin", "Greece" => "Athens", "Ireland"=>"Dublin", "Netherlands"=>"Amsterdam", "Portugal"=>"Lisbon", "Spain"=>"Madrid", "Sweden"=>"Stockholm", "United Kingdom"=>"London", "Cyprus"=>"Nicosia", "Lithuania"=>"Vilnius", "Czech Republic"=>"Prague", "Estonia"=>"Tallin", "Hungary"=>"Budapest", "Latvia"=>"Riga", "Malta"=>"Valetta", "Austria" => "Vienna", "Poland"=>"Warsaw");
	asort($arr);
	foreach($arr as $city => $capital) {
    echo "The capital of " .$city. " is " . $capital;
    echo "<br>";
}
echo "<h2>Task:05</h2>";
   echo "<br>";
$numeric = array(1,2,3,4,5);
echo "NUMERIC ARRAY";
	echo "<br>";
        foreach($numeric as $num){
	echo "$num";
	echo "<br>";
}
$new= array_pad($numeric,7,'@');
echo "NUMERIC ARRAY";
	echo "<br>";
foreach($new as $num){
	echo "$num";
	echo "<br>";
}
array_shift($new);
echo "NUMERIC ARRAY";
	echo "<br>";
foreach($new as $num){
	echo "$num";
	echo "<br>";
}
 echo "<h2>Task:06</h2>";
   echo "<br>";

 echo "Numbers between 200 and 250 taht are divisible by 4:";
 	echo "<br>";

 $divFour=range(200,250,4);
 foreach($divFour as $div){
 	echo $div;
 	echo "<br>";
 }

 echo "<h2>Task:07</h2>";
   echo "<br>";
 $num_array= array(1,2,2,3,4,5,6,7,8,9,0,8,9,5,6,6,6);
 $numa=array_unique($num_array);
 foreach ($numa as $number) {
 	echo $number;
 	echo "<br>";
 	 }
 	 $str_array= array("Hellow","world","HELLOW","wOrld","Hellow");
 $stra=array_unique($str_array);
 foreach ($stra as $string) {
 	echo $string;
 	echo "<br>";	 }
 	echo "<h2>Task:08</h2>";
   echo "<br>";
 	function Name($num="A00"){
 		echo "$num";
 		echo "<br>";
 	}
 	Name("A01");
 	Name("A02");
 	Name("A03");
 	Name("A04");
 	Name("A05");
 	echo "<h2>Task:09</h2>";
   echo "<br>";
$Arr_sort= array("Samreen"=>"31","Jahan"=>"41","Warisha"=>"39","Rania"=>"40") ;
asort($Arr_sort);
echo "<h4>ascending order sort by value</h4>";
	echo "<br>";

foreach($Arr_sort as $name=> $age){
	echo $name." is ".$age." years old";
	echo "<br>";
}
echo "<h4>ascending order sort by Key</h4>";
	echo "<br>";

ksort($Arr_sort);
foreach($Arr_sort as $name=> $age){
	echo $name." is ".$age." years old";
	echo "<br>";}
	echo "<h4>descending order sort by values</h4>";
	echo "<br>";
	arsort($Arr_sort);
	foreach($Arr_sort as $name=> $age){
	echo $name." is ".$age." years old";
	echo "<br>";}
	echo "<h4>descending order sort by keys</h4>";
	echo "<br>";
	krsort($Arr_sort);
	foreach($Arr_sort as $name=> $age){
	echo $name." is ".$age." years old";
	echo "<br>";}
echo "<h2>Task:10</h2>";
   echo "<br>";
	$Name= "Kashmala Khan";
	$array=str_split($Name);
	foreach($array as $arr){
		switch ($arr){
				case 'A':
				echo "Apple";				echo "<br>";

					break;
					case 'B':
				echo "Beautiful";				echo "<br>";

					break;case 'C':
				echo "Cute";				echo "<br>";
					break;case 'D':
				echo "Dog";				echo "<br>";

					break;case 'E':
				echo "Eagle";				echo "<br>";

					break;case 'F':
				echo "Apple";				echo "<br>";

					break;case 'G':
				echo "Grapes"; 				echo "<br>";

					break;case 'H':
				echo "Hat";				echo "<br>";

					break;case 'I':
				echo "Italy";				echo "<br>";

					break;case 'J':
				echo "Joker";				echo "<br>";

					break;case 'K':
				echo "Kangroo";				echo "<br>";

					break;case 'L':
				echo "Leopard";				echo "<br>";

					break;case 'M':
				echo "Monkey";				echo "<br>";

					break;case 'N':
				echo "Netherlands";				echo "<br>";

					break;case 'O':
				echo "Orange";				echo "<br>";

					break;case 'P':
				echo "Princess";				echo "<br>";

					break;case 'Q':
				echo "Queen";				echo "<br>";

					break;case 'R':
				echo "Rabbit";				echo "<br>";

					break;
					case 'S':
				echo "Sober";				echo "<br>";

					break;case 'T':
				echo "Titanic";				echo "<br>";

					break;case 'U':
				echo "Unique";				echo "<br>";

					break;case 'V':
				echo "Vase";				echo "<br>";

					break;case 'W':
				echo "Wild";				echo "<br>";

					break;case 'X':
				echo "XAMPP";				echo "<br>";

					break;case 'Y':
				echo "Yolk";				echo "<br>";

					break;case 'Z':
				echo "Zamzam";				echo "<br>";

					break;
					case 'a':
				echo "Apple";				echo "<br>";

					break;
					case 'b':
				echo "Beautiful";				echo "<br>";

					break;case 'c':
				echo "Cute";				echo "<br>";

					break;case 'd':
				echo "Dog";				echo "<br>";

					break;case 'e':
				echo "Eagle";				echo "<br>";

					break;case 'f':
				echo "Apple";				echo "<br>";
					break;case 'g':
				echo "Grapes";				echo "<br>";

					break;case 'h':
				echo "Hat";				echo "<br>";

					break;case 'i':
				echo "Italy";				echo "<br>";

					break;case 'j':
				echo "Joker";				echo "<br>";

					break;case 'k':
				echo "Kangroo";				echo "<br>";

					break;case 'l':
				echo "Leopard";				echo "<br>";

					break;case 'm':
				echo "Monkey";				echo "<br>";

					break;case 'n':
				echo "Netherlands";				echo "<br>";

					break;case 'o':
				echo "Orange";				echo "<br>";

					break;case 'p':
				echo "Princess"; 				echo "<br>";

					break;case 'q':
				echo "Queen"; 				echo "<br>";

					break;case 'r':
				echo "Rabbit";
								echo "<br>";

					break;
					case 's':
				echo "Sober";
								echo "<br>";

					break;case 't':
				echo "Titanic";
								echo "<br>";

					break;case 'u':
				echo "Unique";
								echo "<br>";

					break;case 'v':
				echo "Vase";
								echo "<br>";

					break;case 'w':
				echo "Wild";
								echo "<br>";

					break;case 'x':
				echo "XAMPP";
								echo "<br>";

					break;case 'y':
				echo "Yolk";
								echo "<br>";

					break;case 'z':
				echo "Zamzam";
				echo "<br>";
					break;
				default:
								echo "<br>";

			}	
	}
	echo "<h2>Task:11</h2>";
   echo "<br>";
	$roll_num= array();
	for ($r=0; $r<=100; $r++){
	   $x=	rand(1,200);
		array_push($roll_num,$x);
	}
	foreach ($roll_num as $roll) {
		echo $roll;
		echo "<br>";
	}
	$Roll_Number=100;
	if(in_array($Roll_Number,$roll_num)){
		echo "<h1>Found You</h1>";
   echo "<br>";
	}
echo "<h2>Task:12</h2>";
   echo "<br>";
   $color = array ( "color" => array ( "a" => "Red", "b" => "Green", "c" => "White"),"numbers" => array ( 1, 2, 3, 4, 5, 6 ),"holes" => array ( "First", 5 => "Second", "Third"));
echo $color["holes"][0];
echo "<br>";
echo $color["color"]["c"];
echo "<br>";
echo $color["numbers"][1];
echo "<br>";
/*function test($a=null,$b=null,$c=null){
echo "Function with arguments".$a." ".$b." ".$c;
echo "<br>";
}
test();
test(90,10,11);
test("kashmala");
test("kashmala","16sw44");
Class Magic{
 function test1(){

 }
	function __call($name,$args){

           if($name=='test1'){
           	switch(count($args)){

                case 0:
                echo "No arguments"; echo "<br>";
                break;
                case 1:
                echo "One argument"; echo "<br>";
                break;case 2:
                echo "Five arguments"; echo "<br>";
                break;
                default:
                echo " ";

           	}
           }
	}
}
$ob=new Magic();
$ob->test1(89);
$ob->test1();
$ob->test1(89,78,90);
$ob->test1(89);
    
    //Method 3 using func_num_args()
function test3(){

	if (func_num_args()==0){
		echo "No arguments";
		echo "<br>";
	}
	if (func_num_args()==1){
	func_get_arg(0);
		echo func_get_arg(0);
				echo "<br>";

	}
	if (func_num_args()==2){
		$arr=func_get_args();
		echo $arr[0]." ".$arr[1];
				echo "<br>";

	}
	
}
test3();
test3("kashmala");
test3("Kashmala","Khan");
//Method 4 using ...
function Test4(...$a){
	foreach($a as $b){
	echo $b;
	echo "<br>";
}}
Test4();
Test4(1);
Test4(2,"Kashmala");*/
echo "<h2>Task:13</h2>";
  echo "<br>";
//$GLOBALS['array_1']="arr1";
//for($c=1; $c<=10; $c++){
	//$arr=substr_replace($array_1,$c,3);
	//echo "$arr";
	//echo "<br>";
    
for($a=1; $a<=10; $a++)
{
echo "<h2>Table of $a:</h2>";
	for ($i=1; $i <=10 ; $i++) { 
$b=$a*$i;
echo "$b";
echo "<br>";
	//}
}}
?>
<table></table>
</body>
</html>